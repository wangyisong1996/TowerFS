Welcome to the magic tower on FUSE !!!

You can use `ls` or `ll` to look around, and use `cd` to move.

To fight with someone, use `./fight`.

To check your game status, use `cat .status`.

To show this README file, use `cat .README`

The goal is to explore everywhere in the tower.
GL & HF !

